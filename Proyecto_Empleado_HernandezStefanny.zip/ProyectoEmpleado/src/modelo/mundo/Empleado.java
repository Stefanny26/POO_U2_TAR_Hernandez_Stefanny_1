package modelo.mundo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Empleado {

	//Atributos
	private String nombreEmpleado;
	private String apellidoEmpleado;
	private int genero;
	private String imagen;
	private double salario;
	
	private Fecha fechaNaciemnto;
	private Fecha fechaIngreso;
	
	// Metodo Constructor sin parametros 
	public Empleado() {
	nombreEmpleado="";	
	apellidoEmpleado="";
	genero=0;
	imagen="";
	salario=0.0;
	}

	// Metodo Constructor con parametros 
	public Empleado(String nombreEmpleado, String apellidoEmpleado, int genero, String imagen, double salario) {
	
		this.nombreEmpleado = nombreEmpleado;
		this.apellidoEmpleado = apellidoEmpleado;
		this.genero = genero;
		this.imagen = imagen;
		this.salario = salario;
	}

	//metodos get
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public String getApellidoEmpleado() {
		return apellidoEmpleado;
	}

	public int getGenero() {
		return genero;
	}

	public String getImagen() {
		return imagen;
	}

	public double getSalario() {
		return salario;
	}
		
	public Fecha getFechaNacimiento() {
		return fechaNaciemnto;
	}
	
	public Fecha getFechaIngreso() {
		return fechaIngreso;
	}
	
	public Fecha getFechaActual() {
		
		GregorianCalendar gc = new GregorianCalendar( );

        int dia = gc.get( Calendar.DAY_OF_MONTH );
        int mes = gc.get( Calendar.MONTH ) + 1;
        int anio = gc.get( Calendar.YEAR );
        Fecha hoy = new Fecha( dia, mes, anio );

        return hoy;
	}
	
	//metodos Setters
	
	public void setEmpleado(String nombreEmpleado, String apellidoEmpleado, int genero, String imagen, double salario) {
		this.nombreEmpleado = nombreEmpleado;
		this.apellidoEmpleado = apellidoEmpleado;
		this.genero = genero;
		this.imagen = imagen;
		this.salario = salario;
	}
	
	public void setSalario(double pSalario) {
		salario = pSalario;
	}

	//metodos funcionale s 
	
		public int calcularAntiguedad() {
			int antiguedad=0;
		    antiguedad = fechaIngreso.darDiferenciaEnMeses( getFechaActual() ) / 12;
		    return antiguedad;
		}
		
		 public int calcularEdad( ){
			    int edad=0;
		        edad = fechaNaciemnto.darDiferenciaEnMeses( getFechaActual()) / 12;
		        return edad;
		    }

		public double calcularPrestaciones() {
			double prestaciones;
			prestaciones= (calcularAntiguedad() * getSalario())/12;
			return prestaciones; 
		}
		
		//M�todo que permite visualizar la informaci�n del empleado
		public void mostrarInformaicn() {
			System.out.println("\nDatos del Empleado ");
			System.out.println("\nNombre: " + nombreEmpleado);
			System.out.println("Apellido: " +apellidoEmpleado );
			System.out.println("Imagen: " + imagen); 
			System.out.println("Genero: " + genero); 
			System.out.println("Salario: " + salario); 
			System.out.println("Prestaciones: " + calcularPrestaciones()); 
			System.out.println("Antiguedad: " + calcularAntiguedad()); 
		}
		
		public void mostrarInformacion() {
			
			  System.out.println("\nDatos del Empleado ");
			  System.out.println("\nNombre: " + nombreEmpleado);
			  System.out.println("Apellido: " +apellidoEmpleado );
			  System.out.println("Genero: " + genero); 
			  //System.out.println("Imagen: " + imagen); 
			  System.out.println("Salario: " + salario); 
			  System.out.println("Prestaciones: " + calcularPrestaciones()); 
			  System.out.println("Antiguedad: " + calcularAntiguedad()); 
		}  
}
